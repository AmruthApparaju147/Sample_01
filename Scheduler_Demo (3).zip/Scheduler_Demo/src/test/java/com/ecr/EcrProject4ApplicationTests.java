package com.ecr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcrProject4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
