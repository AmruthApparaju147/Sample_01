package com.ecr.service;

import com.ecr.model.MetaDetails;
import com.ecr.model.RulesSet;

import java.util.List;

public interface JobService {
	List<MetaDetails> getMetaDetails(String status);
	List<RulesSet> scheduleTaskIfRulesMatch(MetaDetails metaDetails);

}
