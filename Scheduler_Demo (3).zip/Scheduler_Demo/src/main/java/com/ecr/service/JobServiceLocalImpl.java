package com.ecr.service;

import com.ecr.Exception.CustomException;
import com.ecr.model.MetaDetails;
import com.ecr.model.RulesSet;
import com.ecr.repo.DiscoveryQueueRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class JobServiceLocalImpl implements JobService {

    private static final Logger logger = LoggerFactory.getLogger(JobServiceLocalImpl.class);

    public static String result = "";

    @Bean
    public List<RulesSet> validateRules() {
        List<RulesSet> rulesSets = List.of(
                new RulesSet(1, "Company1", "Mailbox1"),
                new RulesSet(2, "Company2", "Mailbox2"),
                new RulesSet(3, "Company3", "Mailbox3")
        );


        return rulesSets;
    }
    @Bean
    public List<MetaDetails> getAllMetaDetails() {
        List<MetaDetails> AllMetaDetails = List.of(

                new MetaDetails(1, "Mailbox1", "Company1", "Data", "N","FileName"), new MetaDetails(2, "Mailbox2", "Company2", "Data", "N","FileName2"),
                new MetaDetails(3, "Mailbox3", "Company3", "Data", "F","FileName3")
        );
        return AllMetaDetails;
    }

    @Override
    public List<MetaDetails> getMetaDetails(String status) {
        logger.info("Fetching meta details with status: {}", status);
        try {
            return getAllMetaDetails().stream()
                    .filter(metaDetails -> metaDetails.getStatus().equalsIgnoreCase(status))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Error fetching meta details", e);
            throw new CustomException("Could not fetch meta details", e);
        }
    }

    @Override
    public List<RulesSet> scheduleTaskIfRulesMatch(MetaDetails metaDetails) {

        logger.info("Received MetaDetails for scheduling: {}", metaDetails);

        List<RulesSet> rules;
        try {
            rules = validateRules()
                    .stream()
                    .filter(i -> i.getCompanyName().equalsIgnoreCase(metaDetails.getCompanyName()))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Error validating rules", e);
            throw new CustomException("Could not validate rules", e);
        }

        List<RulesSet> scheduledRules = new ArrayList<>();

        if (!rules.isEmpty()) {
            for (RulesSet rule : rules) {
                try {
                    scheduleTask(rule);
                    scheduledRules.add(rule);
                } catch (Exception e) {
                    logger.error("Failed to schedule task for rule: {}", rule, e);
                }
            }
        } else {
            logger.warn("No rules matched for MetaDetails: {}", metaDetails);
        }
        return scheduledRules;
    }

    private String scheduleTask(RulesSet rule) {
        logger.info("Scheduling task for rule: {}", rule);
        return "Scheduled task for: " + rule;
    }
}