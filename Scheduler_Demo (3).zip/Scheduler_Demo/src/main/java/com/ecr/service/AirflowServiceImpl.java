package com.ecr.service;

import com.ecr.model.AirFlowRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class AirflowServiceImpl implements AirflowService {

    @Value("${airflow.url}")
    private String airflowUrl;

    @Value("${airflow.username}")
    private String username;

    @Value("${airflow.password}")
    private String password;

    @Autowired
    private  RestTemplate restTemplate;


/*    public String createDag(String dagId, Map<String, Object> conf) {
        String url = airflowUrl + "/api/v1/dags/" + dagId + "/dagRuns";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBasicAuth(username, password);

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("conf", conf);
        requestBody.put("dag_run_id", "manual__" + System.currentTimeMillis());

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);
            return response.getBody();  // The response will contain details about the DAG run
        } catch (Exception e) {
            e.printStackTrace();
            return "Error triggering DAG: " + e.getMessage();
        }
    }*/


    @Override
    public ResponseEntity<String> SendDetails(AirFlowRequest requestData) {
        String url = airflowUrl + "/api/v1/dags/" + requestData.getDagId() + "/dagRuns";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("conf", requestData);

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(
                    airflowUrl,
                    HttpMethod.POST,
                    requestEntity,
                    String.class
            );
            return ResponseEntity.ok(response.getBody());  // Return Airflow's response to the client
        } catch (HttpClientErrorException e) {
            return ResponseEntity.status(e.getStatusCode()).body(e.getResponseBodyAsString());
        }
    }



    @Override
    public String triggerDag(String dagId) {
        String url = airflowUrl + "/api/v1/dags/" + dagId + "/dagRuns";
        System.out.println(dagId+"$$$$$"+url);
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(username, password);
        headers.set("Content-Type", "application/json");
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
            return response.getBody();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error fetching DAG status: " + e.getMessage();
        }
    }
}
