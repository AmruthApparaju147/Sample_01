package com.ecr.service;

import com.ecr.model.AirFlowRequest;
import org.springframework.http.ResponseEntity;

public interface AirflowService {

    String triggerDag(String dagId);

    ResponseEntity<String> SendDetails(AirFlowRequest requestData);
    }
