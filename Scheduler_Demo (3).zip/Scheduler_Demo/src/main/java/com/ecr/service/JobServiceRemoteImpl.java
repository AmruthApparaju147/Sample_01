package com.ecr.service;

import com.ecr.Exception.CustomException;
import com.ecr.model.MetaDetails;
import com.ecr.model.RulesSet;
import com.ecr.repo.DiscoveryQueueRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

//@Service
public class JobServiceRemoteImpl implements  JobService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private DiscoveryQueueRepo repo;

    private static final String RULES_API_URL = "";
    private static final Logger logger = LoggerFactory.getLogger(JobServiceRemoteImpl.class);


    @Override
    public List<MetaDetails> getMetaDetails(String status) {
        logger.info("Fetching meta details with status: {}", status);
        List<MetaDetails> res;
        try {
            res = repo.findByStatus(status);
        } catch (Exception e) {
            logger.error("Error fetching meta details from repository", e);
            throw new CustomException("Could not fetch meta details", e);
        }
        return res;
    }

    @Override
    public List<RulesSet> scheduleTaskIfRulesMatch(MetaDetails metaDetails) {
        logger.info("Received MetaDetails for scheduling: {}", metaDetails);
        List<RulesSet> rulesSets;
        try {
            rulesSets = fetchRulesFromApi();
        } catch (Exception e) {
            logger.error("Error fetching rules from API", e);
            throw new CustomException("Could not fetch rules from API", e);
        }

        List<RulesSet> scheduledRules = new ArrayList<>();

        for (RulesSet rule : rulesSets) {
            if (rule.getCompanyName().equals(metaDetails.getCompanyName())) {
                try {
                    scheduleTask(rule);
                    scheduledRules.add(rule);
                } catch (Exception e) {
                    logger.error("Failed to schedule task for rule: {}", rule, e);
                }
            }
        }

        if (scheduledRules.isEmpty()) {
            logger.warn("No rules scheduled for MetaDetails: {}", metaDetails);
        }

        return scheduledRules;
    }



    private List<RulesSet> fetchRulesFromApi() {
        logger.info("Fetching rules from API at {}", RULES_API_URL);
        try {
            RulesSet[] rulesArray = restTemplate.getForObject(RULES_API_URL, RulesSet[].class);
            return List.of(rulesArray); // Convert array to List
        } catch (Exception e) {
            logger.error("Error while fetching rules from API", e);
            throw new RuntimeException("Could not fetch rules from API", e);
        }
    }
    private void scheduleTask(RulesSet rule) {
        logger.info("Scheduling task for rule: {}", rule);
        System.out.println("Scheduling task for rule: " + rule);
    }}
