package com.ecr.model;

public class AirFlowRequest {

    private String dagId;
    private Integer runSetId;

    public String getDagId() {
        return dagId;
    }

    public void setDagId(String dagId) {
        this.dagId = dagId;
    }

    public Integer getRunSetId() {
        return runSetId;
    }

    public void setRunSetId(Integer runSetId) {
        this.runSetId = runSetId;
    }

    @Override
    public String toString() {
        return "RulesSet{" +
                "dagId=" + dagId +
                ", runSetId='" + runSetId + '\'' +
                '}';    }


}
