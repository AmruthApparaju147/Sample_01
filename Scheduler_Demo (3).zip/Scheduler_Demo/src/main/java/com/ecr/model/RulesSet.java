package com.ecr.model;

public class RulesSet {

  private   Integer rulesId;
  private   String companyName;
  private   String mailBoxName;

  public RulesSet(Integer rulesId, String companyName, String mailBoxName) {
        this.rulesId = rulesId;
        this.companyName = companyName;
        this.mailBoxName = mailBoxName;
    }

    public Integer getRulesId() {
        return rulesId;
    }

    public void setRulesId(Integer rulesId) {
        this.rulesId = rulesId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getMailBoxName() {
        return mailBoxName;
    }

    public void setMailBoxName(String mailBoxName) {
        this.mailBoxName = mailBoxName;
    }

    @Override
    public String toString() {
        return "RulesSet{" +
                "rulesId=" + rulesId +
                ", companyName='" + companyName + '\'' +
                ", mailBoxName='" + mailBoxName + '\'' +
                '}';
    }
}
