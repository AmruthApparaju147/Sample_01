package com.ecr.model;


import org.springframework.context.annotation.Configuration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="discovery_queue")
public class MetaDetails {

    @Id
    private Integer uniqueId;

    @Column(name="mailbox_name")
    private String mailboxName;

    @Column(name="company_name")
    private String companyName;

    @Column(name="unique_meta_data")
    private String uniqueMetaData;

    private String status;

    private String fgfh;

    public MetaDetails()
    {

    }

    // Parameterized constructor
    public MetaDetails(Integer uniqueId, String mailboxName, String companyName, String uniqueMetaData, String status,String fgfh) {
        this.uniqueId = uniqueId;
        this.mailboxName = mailboxName;
        this.companyName = companyName;
        this.uniqueMetaData = uniqueMetaData;
        this.status = status;
        this.fgfh=fgfh;
    }


    // Getters and Setters

    public String getMailboxName() {
        return mailboxName;
    }

    public void setMailboxName(String mailboxName) {
        this.mailboxName = mailboxName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getUniqueMetaData() {
        return uniqueMetaData;
    }

    public void setUniqueMetaData(String uniqueMetaData) {
        this.uniqueMetaData = uniqueMetaData;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(Integer uniqueId) {
        this.uniqueId = uniqueId;
    }

    @Override
    public String toString() {
        return "MetaDetails{" +
                "uniqueId=" + uniqueId +
                ", mailboxName='" + mailboxName + '\'' +
                ", companyName='" + companyName + '\'' +
                ", uniqueMetaData='" + uniqueMetaData + '\'' +
                ", status='" + status + '\'' +
                ", fgfh='" + fgfh + '\'' +
                '}';
    }

    public String getFgfh() {
        return fgfh;
    }

    public void setFgfh(String fgfh) {
        this.fgfh = fgfh;
    }
}
