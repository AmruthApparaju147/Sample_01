package com.ecr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcrProject4Application {

	public static void main(String[] args) {
		SpringApplication.run(EcrProject4Application.class, args);
	}

}
