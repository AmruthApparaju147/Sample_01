package com.ecr.repo;

import com.ecr.model.MetaDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DiscoveryQueueRepo extends JpaRepository<MetaDetails,Integer> {

    List<MetaDetails> findByStatus(String status);
}
