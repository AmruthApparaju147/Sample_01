package com.ecr.controller;

import com.ecr.Exception.CustomException;
import com.ecr.model.MetaDetails;
import com.ecr.model.MetaDetailsRequest;
import com.ecr.model.RulesSet;
import com.ecr.service.JobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.List;

@RestController
public class SchedulerController {

    private static final Logger logger = LoggerFactory.getLogger(SchedulerController.class);

    @Autowired
    private JobService service;

    @PostMapping("/details")
    public List<MetaDetails> getDetails(@RequestBody MetaDetailsRequest metaDetailsRequest) {
        logger.info("Received request for meta details with status: {}", metaDetailsRequest.getStatus());

        try {
            List<MetaDetails> metaDetails = service.getMetaDetails(metaDetailsRequest.getStatus());
            logger.info("Fetched {} meta details for status: {}", metaDetails.size(), metaDetailsRequest.getStatus());
            return metaDetails;
        } catch (Exception e) {
            logger.error("Error occurred while fetching meta details for status: {}", metaDetailsRequest.getStatus(), e);
            throw new CustomException("Unable to fetch meta details", e);
        }
    }

    @PostMapping("/run")
    public ResponseEntity<List<RulesSet>> triggerJob(@RequestBody MetaDetailsRequest metaDetailsRequest) {
        logger.info("Received request to trigger job for status: {}", metaDetailsRequest.getStatus());

        List<RulesSet> scheduledRules = new ArrayList<>();
        try {
            String status = metaDetailsRequest.getStatus();
            List<MetaDetails> metaDetailsList = service.getMetaDetails(status);

            if (!metaDetailsList.isEmpty()) {
                for (MetaDetails details : metaDetailsList) {
                    logger.info("Scheduling task for MetaDetails: {}", details);
                    List<RulesSet> rules = service.scheduleTaskIfRulesMatch(details);
                    scheduledRules.addAll(rules);
                }
            } else {
                logger.warn("No meta details found for status: {}", status);
            }

            return ResponseEntity.ok(scheduledRules);

        } catch (Exception e) {
            logger.error("Error occurred while triggering job for status: {}", metaDetailsRequest.getStatus(), e);
            throw new CustomException("Failed to trigger job", e);
        }
    }
}
