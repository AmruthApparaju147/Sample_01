package com.ecr.controller;

import com.ecr.model.AirFlowRequest;
import com.ecr.service.AirflowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/airflow")
public class AirflowController {

    @Autowired
    private AirflowService airflowService;

    @PostMapping("/trigger/{dagId}")
    public String triggerDag(@PathVariable String dagId) {
        System.out.println(dagId);
        return airflowService.triggerDag(dagId);
    }


@PostMapping("/triggerDetails")
public ResponseEntity<String> triggerDetailsDag(@RequestBody  AirFlowRequest req) {
  System.out.println("***"+req);
    ResponseEntity<String> response = airflowService.SendDetails(req);
    return ResponseEntity.ok("DAG Details send successfully. Response: " + response);
}

    }


